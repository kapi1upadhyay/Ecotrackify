const Group = require('../models/Group');
const Message = require('../models/Message');
const User = require('../models/User');

// Create a new group
exports.createGroup = async (req, res) => {
  try {
    const { name, description, category, privacy, interests } = req.body;

    // Check if group with same name already exists
    const existingGroup = await Group.findOne({ name });
    if (existingGroup) {
      return res.status(400).json({ 
        message: 'A group with this name already exists' 
      });
    }

    // Create new group
    const group = new Group({
      name,
      description,
      category,
      admin: req.user._id,
      members: [req.user._id],
      privacy: privacy || 'public',
      interests: interests || []
    });

    await group.save();

    res.status(201).json({
      message: 'Group created successfully',
      group: {
        id: group._id,
        name: group.name,
        description: group.description,
        category: group.category,
        privacy: group.privacy
      }
    });
  } catch (error) {
    res.status(400).json({ 
      message: 'Group creation failed', 
      error: error.message 
    });
  }
};

// Get all groups user can see (public + user's private groups)
exports.getAllGroups = async (req, res) => {
  
  try {
    const groups = await Group.find({
      $and: [
        { privacy: 'public' },
        { members: { $in: [req.user._id]} }
      ]
    }).populate('admin', 'email name');

    res.json({
      message: 'Groups retrieved successfully',
      groups: groups.map(group => ({
        id: group._id,
        name: group.name,
        description: group.description,
        category: group.category,
        memberCount: group.members.length,
        admin: group.admin.email
      }))
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Failed to retrieve groups', 
      error: error.message 
    });
  }
};

// Join a group
exports.joinGroup = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    // Check if user is already a member
    if (group.members.includes(req.user._id)) {
      return res.status(400).json({ message: 'Already a member of this group' });
    }

    // Check group privacy
    if (group.privacy === 'private') {
      return res.status(403).json({ message: 'Cannot join a private group' });
    }

    // Add user to group members
    group.members.push(req.user._id);
    await group.save();

    res.json({
      message: 'Joined group successfully',
      group: {
        id: group._id,
        name: group.name,
        memberCount: group.members.length
      }
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Failed to join group', 
      error: error.message 
    });
  }
};

// Send a message in a group
exports.sendMessage = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);

    // Verify user is a member of the group
    if (!group.members.includes(req.user._id)) {
      return res.status(403).json({ message: 'Not a member of this group' });
    }

    const message = new Message({
      group: group._id,
      sender: req.user._id,
      content: req.body.content
    });

    await message.save();

    res.status(201).json({
      message: 'Message sent successfully',
      messageDetails: {
        id: message._id,
        content: message.content,
        sender: req.user.email,
        createdAt: message.createdAt
      }
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Failed to send message', 
      error: error.message 
    });
  }
};

// Get group messages
exports.getGroupMessages = async (req, res) => {
  try {
    const group = await Group.findById(req.params.groupId);

    // Verify user is a member of the group
    if (!group.members.includes(req.user._id)) {
      return res.status(403).json({ message: 'Not a member of this group' });
    }

    const messages = await Message.find({ group: group._id.toString() })
      
      .limit(50)
      .populate('sender', 'email name');

    res.json({
      messages: messages.map(msg => ({
        id: msg._id,
        content: msg.content,
        sender: msg.sender.email,
        createdAt: msg.createdAt
      }))
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Failed to retrieve messages', 
      error: error.message 
    });
  }
};

// Explore groups (public groups user is not a member of)
exports.exploreGroups = async (req, res) => {
 
  
  try {
    const groups = await Group.find({ 
      privacy: 'public', 
      members: { $nin: [req.user._id] }
    }).populate('admin', 'email name');
    console.log(groups);
    res.json({ 
      message: 'Explorable groups retrieved successfully',
      groups: groups.map(group => ({
        id: group._id,
        name: group.name,
        description: group.description,
        category: group.category,
        memberCount: group.members.length,
        admin: group.admin.email
      }))
    });
   
  } catch (error) {
    res.status(500).json({ 
      message: 'Failed to explore groups', 
      error: error.message 
    });
    
  }
};