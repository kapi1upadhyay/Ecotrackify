// controllers/sustainableOptionController.js
const SustainableOption = require('../models/SustainableOption');
const UserGoal = require('../models/UserGoal');

exports.getAllOptions = async (req, res) => {
  try {
    const options = await SustainableOption.find();
    res.json(options);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching options', error: error.message });
  }
};

exports.getOptionById = async (req, res) => {
  try {
    const option = await SustainableOption.findById(req.params.id);
    if (!option) {
      return res.status(404).json({ message: 'Option not found' });
    }
    res.json(option);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching option details', error: error.message });
  }
};

exports.createOption = async (req, res) => {
  try {
    const newOption = new SustainableOption(req.body);
    await newOption.save();
    res.status(201).json(newOption);
  } catch (error) {
    res.status(400).json({ message: 'Error creating option', error: error.message });
  }
};

exports.addToGoals = async (req, res) => {
  try {
    const { optionId, userId } = req.body;
    
    const userGoal = await UserGoal.findOneAndUpdate(
      { user: userId },
      { $addToSet: { sustainableOptions: { option: optionId } } },
      { upsert: true, new: true }
    );

    res.status(201).json(userGoal);
  } catch (error) {
    res.status(400).json({ message: 'Error adding to goals', error: error.message });
  }
};