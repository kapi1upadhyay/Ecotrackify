// models/SustainableOption.js
const mongoose = require('mongoose');

const SustainableOptionSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  category: {
    type: String,
    enum: ['Recycling', 'Composting', 'Renewable Energy'],
    required: true
  },
  description: {
    type: String,
    required: true
  },
  detailedInformation: {
    benefits: String,
    steps: [String],
    estimatedImpact: {
      carbonReduction: Number,
      resourceSaving: Number
    }
  },

  
}, { timestamps: true });

module.exports = mongoose.model('SustainableOption', SustainableOptionSchema);