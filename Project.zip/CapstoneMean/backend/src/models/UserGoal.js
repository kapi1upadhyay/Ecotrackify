// models/UserGoal.js
const mongoose = require('mongoose');

const UserGoalSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  sustainableOptions: [{
    option: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'SustainableOption'
    },
    status: {
      type: String,
      enum: ['Not Started', 'In Progress', 'Completed'],
      default: 'Not Started'
    },
    addedAt: {
      type: Date,
      default: Date.now
    }
  }]
}, { timestamps: true });

module.exports = mongoose.model('UserGoal', UserGoalSchema);