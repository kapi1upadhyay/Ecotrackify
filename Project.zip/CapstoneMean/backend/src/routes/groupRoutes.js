const express = require('express');
const router = express.Router();
const groupController = require('../controllers/groupController');
const auth = require('../middleware/auth');

// Group routes with authentication middleware
router.post('/', auth, groupController.createGroup);
router.get('/', auth, groupController.getAllGroups);
router.get('/explore', auth, groupController.exploreGroups);
router.post('/:groupId/join', auth, groupController.joinGroup);
router.post('/:groupId/messages', auth, groupController.sendMessage);
router.get('/:groupId/messages', auth, groupController.getGroupMessages);

module.exports = router;