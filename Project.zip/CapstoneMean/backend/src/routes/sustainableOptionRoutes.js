// routes/sustainableOptionRoutes.js
const express = require('express');
const router = express.Router();
const { 
  getAllOptions, 
  getOptionById, 
  createOption,
  addToGoals 
} = require('../controllers/sustainableOptionController');

// Get all sustainable options
router.get('/', getAllOptions);

// Get detailed information about a specific option
router.get('/:id', getOptionById);

// Create a new sustainable option
router.post('/', createOption);

// Add a sustainable option to user's goals
router.post('/add-to-goals', addToGoals);

module.exports = router;