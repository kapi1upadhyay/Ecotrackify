import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/guards/auth.guard';

// Import all your components
import { LandingPageComponent } from './modules/landing-page/landing-page.component'; 

// Auth Components
import { LoginComponent } from './modules/auth/login/login.component';
import { RegisterComponent } from './modules/auth/register/register.component';
import { ForgotPasswordComponent } from './modules/auth/forgot-password/forgot-password.component';

// Dashboard Components
import { CarbonTrackingComponent } from './modules/dashboard/carbon-tracking/carbon-tracking.component';
import { SustainabilityGoalsComponent } from './modules/dashboard/sustainability-goals/sustainability-goals.component';
import { ProfileComponent } from './modules/dashboard/profile/profile.component';

// Groups Components
import { CreateGroupComponent } from './modules/groups/create-group/create-group.component';
import { GroupListComponent } from './modules/groups/group-list/group-list.component';
import { GroupDetailComponent } from './modules/groups/group-detail/group-detail.component';
import { ExploreGroupsComponent } from './modules/groups/explore-groups/explore-groups.component';

// Sustainable Options Components
import { SustainableOptionsListComponent } from './components/sustainable-options-list/sustainable-options-list.component';
import { CreateOptionComponent } from './components/create-option/create-option.component';

// Eco Tips Components
import { CreateTipComponent } from './modules/eco-tips/create-tip/create-tip.component';
import { TipListComponent } from './modules/eco-tips/tip-list/tip-list.component';

// Reports Components
import { CarbonFootprintReportComponent } from './modules/reports/carbon-footprint/carbon-footprint.component';
import { GoalsProgressReportComponent } from './modules/reports/goals-progress/goals-progress.component';

// Define routes with explicit type
export const routes: Routes = [
  // Public Routes
  { path: '', component: LandingPageComponent }, 
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },

  // Protected Dashboard Routes
  {
    path: 'dashboard',
    canActivate: [AuthGuard],
    children: [
      { path: 'carbon-tracking', component: CarbonTrackingComponent },
      { path: 'goals', component: SustainabilityGoalsComponent },
      { path: 'profile', component: ProfileComponent },
      { path: '', redirectTo: 'profile', pathMatch: 'full' }
    ]
  },

  // Protected Groups Routes
  {
    path: 'groups',
    canActivate: [AuthGuard],
    children: [
      { path: 'create', component: CreateGroupComponent },
      { path: 'list', component: GroupListComponent },
      { path: 'detail/:id', component: GroupDetailComponent },
      { path: 'explore', component: ExploreGroupsComponent },
      { path: '', redirectTo: 'list', pathMatch: 'full' }
    ]
  },

  // Protected Sustainable Options Routes
  {
    path: 'sustainable-options',
    canActivate: [AuthGuard],
    children: [
      { path: 'list', component: SustainableOptionsListComponent },
      { path: 'create', component: CreateOptionComponent },
      { path: '', redirectTo: 'list', pathMatch: 'full' }
    ]
  },

  // Protected Eco Tips Routes
  {
    path: 'eco-tips',
    canActivate: [AuthGuard],
    children: [
      { path: 'create', component: CreateTipComponent },
      { path: 'list', component: TipListComponent },
      { path: '', redirectTo: 'list', pathMatch: 'full' }
    ]
  },

  // Protected Reports Routes
  {
    path: 'reports',
    canActivate: [AuthGuard],
    children: [
      { path: 'carbon-footprint', component: CarbonFootprintReportComponent },
      { path: 'goals-progress', component: GoalsProgressReportComponent },
      { path: '', redirectTo: 'carbon-footprint', pathMatch: 'full' }
    ]
  },

  // 404 Redirect - Keep this last
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    // Optional: Enable tracing for debugging
    // enableTracing: true 
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }