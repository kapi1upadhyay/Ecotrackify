import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { provideRouter } from '@angular/router';
import { routes } from './app-routing.module';
import { MatSnackBarModule } from '@angular/material/snack-bar';

import { LandingPageComponent } from './modules/landing-page/landing-page.component';
import { AppComponent } from './app.component';
import { SustainableOptionsListComponent } from './components/sustainable-options-list/sustainable-options-list.component';
import { OptionDetailsModalComponent } from './components/option-details-modal/option-details-modal.component';
import { SustainableOptionService } from './core/services/sustainable-option.service';


import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent, 
    LandingPageComponent,
    SustainableOptionsListComponent,
    OptionDetailsModalComponent,
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatSnackBarModule
  ],
  providers: [
    provideRouter(routes),[SustainableOptionService]
  ],
  bootstrap: [AppComponent] 
})
export class AppModule { }
