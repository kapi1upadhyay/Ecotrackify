import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SustainableOptionService } from '../../core/services/sustainable-option.service';
import { SustainableOption } from '../../models/sustainable-option';
import { LoginNavbarComponent } from '../../modules/login-navbar/login-navbar.component';

@Component({
  selector: 'app-create-option',
  templateUrl: './create-option.component.html',
  styleUrls: ['./create-option.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, LoginNavbarComponent]
})
export class CreateOptionComponent {
  newOption: SustainableOption = {
    name: '',
    category: 'Recycling',
    description: '',
    detailedInformation: {
      benefits: '',
      steps: [],
      estimatedImpact: {
        carbonReduction: 0,
        resourceSaving: 0
      }
    }
  };

  categories: string[] = ['Recycling', 'Composting', 'Renewable Energy'];
  isSubmitting = false;
  error: string | null = null;

  constructor(
    private optionService: SustainableOptionService,
    private router: Router
  ) {}

  onSubmit() {
    if (!this.validateForm()) {
      this.error = 'Please fill in all required fields';
      return;
    }

    this.isSubmitting = true;
    this.error = null;

    this.optionService.createOption(this.newOption).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.router.navigate(['/sustainable-options/list']);
      },
      error: (err) => {
        this.isSubmitting = false;
        this.error = err.message || 'Failed to create option';
      }
    });
  }

  private validateForm(): boolean {
    return !!(
      this.newOption.name.trim() && 
      this.newOption.category && 
      this.newOption.description.trim()
    );
  }
}