import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SustainableOption } from '../../models/sustainable-option';
import { SustainableOptionService } from '../../core/services/sustainable-option.service';

@Component({
  selector: 'app-option-details-modal',
  templateUrl: './option-details-modal.component.html',
  styleUrls: ['./option-details-modal.component.css'],
  standalone: true,
  imports: [CommonModule]
})
export class OptionDetailsModalComponent {
  @Input() option!: SustainableOption;
  @Output() close = new EventEmitter<void>();

  isAdding = false;
  error: string | null = null;

  constructor(private optionService: SustainableOptionService) {}

  addToGoals() {
    if (!this.option?._id) {
      this.error = 'Invalid option selected';
      return;
    }

    this.isAdding = true;
    this.error = null;

    this.optionService.addToGoals(this.option._id).subscribe({
      next: () => {
        this.isAdding = false;
        this.close.emit();
      },
      error: (err) => {
        this.isAdding = false;
        this.error = err.message || 'Failed to add to goals';
      }
    });
  }
}