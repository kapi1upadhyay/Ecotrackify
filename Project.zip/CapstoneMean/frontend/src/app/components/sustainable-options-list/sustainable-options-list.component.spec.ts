import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SustainableOptionsListComponent } from './sustainable-options-list.component';

describe('SustainableOptionsListComponent', () => {
  let component: SustainableOptionsListComponent;
  let fixture: ComponentFixture<SustainableOptionsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SustainableOptionsListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SustainableOptionsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
