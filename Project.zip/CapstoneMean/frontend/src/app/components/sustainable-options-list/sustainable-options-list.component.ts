import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { SustainableOptionService } from '../../core/services/sustainable-option.service';
import { SustainableOption } from '../../models/sustainable-option';
import { Observable } from 'rxjs';
import { OptionDetailsModalComponent } from '../option-details-modal/option-details-modal.component';
import { LoginNavbarComponent } from '../../modules/login-navbar/login-navbar.component';

@Component({
  selector: 'app-sustainable-options-list',
  templateUrl: './sustainable-options-list.component.html',
  styleUrls: ['./sustainable-options-list.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule, OptionDetailsModalComponent, LoginNavbarComponent]
})
export class SustainableOptionsListComponent implements OnInit {
  options$: Observable<SustainableOption[]>;
  loading$: Observable<boolean>;
  error$: Observable<string | null>;
  selectedOption: SustainableOption | null = null;

  constructor(private optionService: SustainableOptionService) {
    this.options$ = this.optionService.options$;
    this.loading$ = this.optionService.loading$;
    this.error$ = this.optionService.error$;
  }

  ngOnInit() {
    this.loadOptions();
  }

  loadOptions() {
    this.optionService.fetchOptions().subscribe({
      error: (error) => console.error('Error loading options:', error)
    });
  }

  openDetailsModal(option: SustainableOption) {
    this.selectedOption = option;
  }

  closeDetailsModal() {
    this.selectedOption = null;
  }
}