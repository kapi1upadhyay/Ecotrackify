import { Injectable } from '@angular/core';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router
} from '@angular/router';
import { TokenService } from '../services/token.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  // Comprehensive list of public routes
  private publicRoutes = [
    '/',
    '/login', 
    '/register', 
    '/forgot-password'
  ];

  constructor(
    private tokenService: TokenService,
    private router: Router
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    const currentPath = state.url;

    // Detailed logging for debugging
    console.log('Attempting to access route:', currentPath);
    console.log('Token valid:', this.tokenService.isTokenValid());

    // Check if route is public
    if (this.isPublicRoute(currentPath)) {
      return true;
    }

    // Check token validity
    if (this.tokenService.isTokenValid()) {
      return true;
    }

    // Redirect to login with return URL
    this.router.navigate(['/login'], {
      queryParams: { 
        returnUrl: state.url,
        message: 'Please login to access this page' 
      }
    });
    return false;
  }

  // Enhanced public route checking
  private isPublicRoute(route: string): boolean {
    // Exact match or starts with public routes
    return this.publicRoutes.some(publicRoute => 
      route === publicRoute || 
      (publicRoute !== '/' && route.startsWith(publicRoute))
    );
  }
}