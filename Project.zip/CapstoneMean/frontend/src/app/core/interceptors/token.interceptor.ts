import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { TokenService } from '../services/token.service';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

export const tokenInterceptor: HttpInterceptorFn = (req, next) => {
  const tokenService = inject(TokenService);
  const router = inject(Router);
  
  const token = tokenService.getToken();
  
  if (token) {
    const clonedRequest = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    
    return next(clonedRequest).pipe(
      catchError((error) => {
        // Handle 401 (Unauthorized) errors
        if (error.status === 401) {
          // Token is invalid or expired
          tokenService.removeToken();
          
          // Redirect to login
          router.navigate(['/login'], {
            queryParams: { 
              message: 'Your session has expired. Please log in again.',
              returnUrl: router.url 
            }
          });
        }
        
        // Re-throw other errors
        return throwError(() => error);
      })
    );
  }
  
  return next(req);
};