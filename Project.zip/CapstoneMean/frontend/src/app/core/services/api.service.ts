import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable} from 'rxjs';
import { environment } from '../../../enviornments/enviornment';
import { BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = environment.apiUrl;
  private groupsSubject = new BehaviorSubject<any[]>([]);
  groups$ = this.groupsSubject.asObservable();

  constructor(private http: HttpClient) {}

 

  get(endpoint: string, params?: any): Observable<any> {
    return this.http.get(`${this.apiUrl}/${endpoint}`, { params });
  }
  

  post(endpoint: string, body: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/${endpoint}`, body);
  }

  put(endpoint: string, body: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/${endpoint}`, body);
  }

  delete(endpoint: string): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${endpoint}`);
  }

  getGroups() {
    this.http.get<{ groups: any[] }>('/groups').subscribe(response => {
      this.groupsSubject.next(response.groups);
    });
  }
 
 

}