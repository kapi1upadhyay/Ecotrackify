import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../enviornments/enviornment';
import { TokenService } from '../services/token.service'; // Import TokenService

@Injectable({
  providedIn: 'root'
})
export class GroupService {
  private apiUrl = `${environment.apiUrl}/api/v1/groups`;

  constructor(
    private http: HttpClient,
    private tokenService: TokenService // Inject TokenService
  ) {}

  // Method to check if user is authenticated before making API calls
  private ensureAuthenticated(): void {
    if (!this.tokenService.isTokenValid()) {
      throw new Error('Unauthorized: Please log in');
    }
  }

  getAllGroups(): Observable<any> {
    this.ensureAuthenticated(); // Check authentication
    return this.http.get(this.apiUrl);
  }

  createGroup(groupData: any): Observable<any> {
    this.ensureAuthenticated(); // Check authentication
    return this.http.post(this.apiUrl, groupData);
  }

  joinGroup(groupId: string): Observable<any> {
    this.ensureAuthenticated(); // Check authentication
    return this.http.post(`${this.apiUrl}/${groupId}/join`, {});
  }

  sendMessage(groupId: string, content: string): Observable<any> {
    this.ensureAuthenticated(); // Check authentication
    return this.http.post(`${this.apiUrl}/${groupId}/messages`, { content });
  }

  getGroupMessages(groupId: string): Observable<any> {
    this.ensureAuthenticated(); // Check authentication
    return this.http.get(`${this.apiUrl}/${groupId}/messages`);
  }
}