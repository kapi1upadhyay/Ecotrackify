import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../../enviornments/enviornment';
import { Group, Message } from '../../../models/group.model';

@Injectable({
  providedIn: 'root'
})
export class GroupService {
  private apiUrl = `${environment.apiUrl}/groups`;

  constructor(private http: HttpClient) {}

  // Create a new group
  createGroup(groupData: Group): Observable<any> {
    return this.http.post(this.apiUrl, groupData);
  }

  // Get all groups
  getAllGroups(): Observable<{ groups: Group[] }> {
    return this.http.get<{ groups: Group[] }>(this.apiUrl);
  }

  // Get group details
  getGroupDetail(groupId: string): Observable<Group> {
    return this.http.get<Group>(`${this.apiUrl}/${groupId}`);
  }

  // Explore public groups
  exploreGroups(): Observable<{ groups: Group[] }> {
    return this.http.get<{ groups: Group[] }>(`${this.apiUrl}/explore`);
  }

  // Join a group
  joinGroup(groupId: string): Observable<any> {
    console.log(groupId);
    
    return this.http.post(`${this.apiUrl}/${groupId}/join`, {});
  }

  // Send a message in a group
  sendMessage(groupId: string, content: string): Observable<Message> {
    return this.http.post<Message>(`${this.apiUrl}/${groupId}/messages`, { content });
  }

  // Get group messages
  getGroupMessages(groupId: string): Observable<{ messages: Message[] }> {
    return this.http.get<{ messages: Message[] }>(`${this.apiUrl}/${groupId}/messages`);
  }
}