import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject, catchError, tap, throwError } from 'rxjs';
import { SustainableOption } from '../../models/sustainable-option';

@Injectable({
  providedIn: 'root'
})
export class SustainableOptionService {
  private apiUrl = 'http://localhost:3000/api/v1/eco1';
  private optionsSubject = new BehaviorSubject<SustainableOption[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private errorSubject = new BehaviorSubject<string | null>(null);

  options$ = this.optionsSubject.asObservable();
  loading$ = this.loadingSubject.asObservable();
  error$ = this.errorSubject.asObservable();

  constructor(private http: HttpClient) {}

  private getAuthHeaders(token: string) {
    return {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      })
    };
  }

  fetchOptions(): Observable<SustainableOption[]> {
    this.loadingSubject.next(true);
    return this.http.get<SustainableOption[]>(this.apiUrl).pipe(
      tap(options => {
        this.optionsSubject.next(options);
        this.loadingSubject.next(false);
        this.errorSubject.next(null);
      }),
      catchError(error => {
        this.loadingSubject.next(false);
        this.errorSubject.next(error.message || 'An error occurred while fetching options');
        return throwError(() => error);
      })
    );
  }

  createOption(option: Partial<SustainableOption>): Observable<SustainableOption> {
    const token = localStorage.getItem('token');
    if (!token) {
      return throwError(() => new Error('Please log in to create options'));
    }

    return this.http.post<SustainableOption>(this.apiUrl, option, this.getAuthHeaders(token)).pipe(
      tap(newOption => {
        const currentOptions = this.optionsSubject.value;
        this.optionsSubject.next([...currentOptions, newOption]);
      }),
      catchError(error => {
        this.errorSubject.next(error.message || 'Failed to create option');
        return throwError(() => error);
      })
    );
  }

  addToGoals(optionId: string, token: string): Observable<any> {
    if (!token) {
      return throwError(() => new Error('Please log in to add goals'));
    }

    // Update the endpoint to match your backend
    return this.http.post(`${this.apiUrl}/goals`, 
      { sustainableOptionId: optionId },  // Update the payload structure to match your backend
      this.getAuthHeaders(token)
    ).pipe(
      catchError(error => {
        const errorMessage = error.error?.message || error.message || 'Failed to add to goals';
        this.errorSubject.next(errorMessage);
        return throwError(() => new Error(errorMessage));
      })
    );
  }
}