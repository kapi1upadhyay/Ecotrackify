import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { SustainableOption } from '../../models/sustainable-option';

@Injectable({
  providedIn: 'root'
})
export class SustainableOptionService {
  private apiUrl = 'http://localhost:3000/api/v1/eco1';
  private optionsSubject = new BehaviorSubject<SustainableOption[]>([]);
  private loadingSubject = new BehaviorSubject<boolean>(false);
  private errorSubject = new BehaviorSubject<string | null>(null);

  options$ = this.optionsSubject.asObservable();
  loading$ = this.loadingSubject.asObservable();
  error$ = this.errorSubject.asObservable();

  constructor(private http: HttpClient) {}

  fetchOptions(): Observable<SustainableOption[]> {
    this.loadingSubject.next(true);
    return this.http.get<SustainableOption[]>(this.apiUrl).pipe(
      tap(options => {
        this.optionsSubject.next(options);
        this.loadingSubject.next(false);
        this.errorSubject.next(null);
      }),
      catchError(error => {
        this.loadingSubject.next(false);
        this.errorSubject.next(error.message || 'Failed to fetch options');
        return throwError(() => error);
      })
    );
  }

  createOption(option: SustainableOption): Observable<SustainableOption> {
    return this.http.post<SustainableOption>(this.apiUrl, option).pipe(
      tap(newOption => {
        const currentOptions = this.optionsSubject.value;
        this.optionsSubject.next([...currentOptions, newOption]);
      }),
      catchError(error => {
        this.errorSubject.next(error.message || 'Failed to create option');
        return throwError(() => error);
      })
    );
  }

  addToGoals(optionId: string): Observable<any> {
    // Get the user ID from localStorage
    const token = localStorage.getItem('token');
    if (!token) {
      return throwError(() => new Error('User not authenticated'));
    }

    // Decode the JWT token to get the user ID
    const userId = this.getUserIdFromToken(token);
    if (!userId) {
      return throwError(() => new Error('Invalid user token'));
    }

    return this.http.post(`${this.apiUrl}/add-to-goals`, { 
      optionId, 
      userId 
    }).pipe(
      catchError(error => {
        const errorMessage = error.error?.message || 'Failed to add to goals';
        this.errorSubject.next(errorMessage);
        return throwError(() => new Error(errorMessage));
      })
    );
  }

  private getUserIdFromToken(token: string): string | null {
    try {
      // Decode the JWT token
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(atob(base64).split('').map(c => {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
      }).join(''));

      const payload = JSON.parse(jsonPayload);
      return payload.userId || payload.sub || null;
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  }
}