import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode'; // Make sure to install jwt-decode

interface TokenPayload {
  exp: number;
  iat: number;
  userId?: string;
  email?: string;
  // Add other claims as per your JWT structure
}

@Injectable({
  providedIn: 'root'
})
export class TokenService {
  private tokenKey = 'user_token';

  setToken(token: string): void {
    localStorage.setItem(this.tokenKey, token);
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  removeToken(): void {
    localStorage.clear()

  }

  isTokenValid(): boolean {
    const token = this.getToken();

    // Check if token exists
    if (!token) {
      return false;
    }

    try {
      // Decode the token
      const decodedToken = this.decodeToken(token);

      // Check token expiration
      const currentTime = Math.floor(Date.now() / 1000);
      return decodedToken.exp > currentTime;
    } catch (error) {
      console.error('Token validation error:', error);
      return false;
    }
  }

  // Decode token with type safety
  decodeToken(token: string): TokenPayload {
    try {
      return jwtDecode<TokenPayload>(token);
    } catch (error) {
      console.error('Error decoding token:', error);
      throw new Error('Invalid token');
    }
  }

  // Get token details
  getTokenDetails(): TokenPayload | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      return this.decodeToken(token);
    } catch (error) {
      return null;
    }
  }

  // Get time remaining before token expiration
  getTokenExpirationTime(): number | null {
    const token = this.getToken();
    if (!token) return null;

    try {
      const decoded = this.decodeToken(token);
      const currentTime = Math.floor(Date.now() / 1000);
      return decoded.exp - currentTime;
    } catch (error) {
      return null;
    }
  }

  // Optional: Get user ID from token
  getUserId(): string | null {
    const details = this.getTokenDetails();
    return details?.userId || null;
  }
}