export interface Group {
    id?: string;
    name: string;
    description: string;
    category: 'Climate Change' | 'Renewable Energy' | 'Waste Reduction' | 'Sustainable Living' | 'Conservation' | 'Environmental Education';
    privacy: 'public' | 'private';
    members?: string[];
    admin?: string;
    interests?: string[];
    memberCount?: number;
  }
  
  export interface Message {
    id?: string;
    content: string;
    sender: string;
    createdAt: Date;
  }