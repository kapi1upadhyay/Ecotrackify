export interface SustainableOption {
    _id?: string;
    name: string;
    category: 'Recycling' | 'Composting' | 'Renewable Energy';
    description: string;
    detailedInformation?: {
      benefits?: string;
      steps?: string[];
      estimatedImpact?: {
        carbonReduction?: number;
        resourceSaving?: number;
      };
    };
  }