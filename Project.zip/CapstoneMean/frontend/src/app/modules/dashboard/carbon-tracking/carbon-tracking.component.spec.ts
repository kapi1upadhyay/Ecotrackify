import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarbonTrackingComponent } from './carbon-tracking.component';

describe('CarbonTrackingComponent', () => {
  let component: CarbonTrackingComponent;
  let fixture: ComponentFixture<CarbonTrackingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CarbonTrackingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CarbonTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
