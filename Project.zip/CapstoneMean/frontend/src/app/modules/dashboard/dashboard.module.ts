// src/app/modules/dashboard/dashboard.module.ts
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { CarbonTrackingComponent } from './carbon-tracking/carbon-tracking.component';
import { SustainabilityGoalsComponent } from './sustainability-goals/sustainability-goals.component';
import { ProfileComponent } from './profile/profile.component';

@NgModule({
  declarations: [
    CarbonTrackingComponent,
    SustainabilityGoalsComponent,
    ProfileComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ]
})
export class DashboardModule { }