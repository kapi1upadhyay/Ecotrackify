import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ApiService } from '../../../core/services/api.service';
import { LoginNavbarComponent } from '../../login-navbar/login-navbar.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    RouterModule,
    LoginNavbarComponent
  ]
})
export class ProfileComponent implements OnInit {
  profileForm: FormGroup;
  profile: any = {
    sustainabilityGoals: [],
    carbonFootprint: {}
  };
  editMode = false;
  isLoading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder, 
    private apiService: ApiService
  ) {
    this.profileForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      userType: ['', Validators.required]
    });
  }

  ngOnInit() {
    this.fetchProfile();
  }

  fetchProfile() {
    this.isLoading = true;
    this.errorMessage = '';

    this.apiService.get('profile').subscribe({
      next: (response) => {
        this.profile = response;
        this.profileForm.patchValue({
          email: response.email,
          userType: response.userType || ''
        });
        this.isLoading = false;
      },
      error: (error) => {
        this.errorMessage = 'Failed to load profile. Please try again.';
        this.isLoading = false;
        console.error('Profile fetch failed', error);
      }
    });
  }

  onSubmit() {
    if (this.profileForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';

      this.apiService.put('profile', this.profileForm.value).subscribe({
        next: (response) => {
          this.profile = { ...this.profile, ...response };
          this.editMode = false;
          this.isLoading = false;
          localStorage.setItem('userType',this.profileForm.value.userType)
          window.location.reload();
        },
        error: (error) => {
          this.errorMessage = 'Profile update failed. Please try again.';
          this.isLoading = false;
          console.error('Profile update failed', error);
        }
      });
    }
  }

  // Progress bar color helper
  getProgressColor(progress: number): string {
    if (progress < 25) return 'danger';
    if (progress < 50) return 'warning';
    if (progress < 75) return 'info';
    return 'success';
  }

  // Goal tracking helper
  trackGoalById(index: number, goal: any): string {
    return goal._id || index;
  }
}