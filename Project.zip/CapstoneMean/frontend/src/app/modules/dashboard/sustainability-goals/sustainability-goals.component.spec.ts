import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SustainabilityGoalsComponent } from './sustainability-goals.component';

describe('SustainabilityGoalsComponent', () => {
  let component: SustainabilityGoalsComponent;
  let fixture: ComponentFixture<SustainabilityGoalsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SustainabilityGoalsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SustainabilityGoalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
