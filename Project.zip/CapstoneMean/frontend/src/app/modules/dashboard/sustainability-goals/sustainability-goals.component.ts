import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { 
  ReactiveFormsModule, 
  FormBuilder, 
  FormGroup, 
  Validators 
} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ApiService } from '../../../core/services/api.service';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

interface Goal {
  id: string;
  goal: string;
  category: string;
  initialData: number;
  target: number;
  date: string;
  progress: number;
  status: string;
}

@Component({
  selector: 'app-sustainability-goals',
  templateUrl: './sustainability-goals.component.html',
  styleUrls: ['./sustainability-goals.component.css'],
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule,
    RouterModule
  ]
})
export class SustainabilityGoalsComponent implements OnInit, AfterViewInit {
  @ViewChild('goalsChart', { static: false }) goalsChart!: ElementRef;

  goalsForm: FormGroup;
  goals: Goal[] = [];
  chart: Chart | null = null;
  isLoading = false;
  errorMessage = '';
  editingGoal: Goal | null = null;

  categories = [
    { value: 'energy', label: 'Energy', icon: '⚡' },
    { value: 'transportation', label: 'Transportation', icon: '🚗' },
    { value: 'waste', label: 'Waste', icon: '♻️' },
    { value: 'water', label: 'Water', icon: '💧' },
    { value: 'general', label: 'General', icon: '🌍' }
  ];

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService
  ) {
    this.goalsForm = this.createForm();
  }

  ngOnInit() {
    this.fetchGoals();
  }

  ngAfterViewInit() {
    if (this.goals.length > 0) {
      this.createGoalsChart();
    }
  }

  private createForm(): FormGroup {
    return this.fb.group({
      goal: ['', [
        Validators.required, 
        Validators.minLength(3), 
        Validators.maxLength(100)
      ]],
      category: ['energy', Validators.required],
      initialData: [0, [
        Validators.required, 
        Validators.min(0), 
        Validators.max(1000000)
      ]],
      target: [0, [
        Validators.required, 
        Validators.min(0), 
        Validators.max(1000000)
      ]],
      date: ['', Validators.required]
    });
  }

  fetchGoals() {
    this.isLoading = true;
    this.errorMessage = '';

    this.apiService.get('goals').subscribe({
      next: (response: any) => {
        this.goals = response.goals || [];
        this.isLoading = false;
        this.createGoalsChart();
      },
      error: (error: any) => {
        console.error('Failed to fetch goals', error);
        this.errorMessage = error.error?.message || 'Failed to fetch goals';
        this.goals = [];
        this.isLoading = false;
      }
    });
  }

  startEditGoal(goal: Goal) {
    this.editingGoal = goal;
    this.goalsForm.patchValue({
      goal: goal.goal,
      category: goal.category,
      initialData: goal.initialData,
      target: goal.target,
      date: goal.date.split('T')[0]
    });
  }

  onSubmit() {
    if (this.goalsForm.invalid) {
      this.markFormGroupTouched(this.goalsForm);
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const formData = {
      ...this.goalsForm.value,
      date: new Date(this.goalsForm.value.date).toISOString().split('T')[0]
    };

    if (this.editingGoal) {
      this.apiService.put(`goals/${this.editingGoal.id}`, formData)
        .subscribe({
          next: (response: any) => {
            const updatedGoal = response.goal;
            const index = this.goals.findIndex(g => g.id === this.editingGoal?.id);
            if (index !== -1) {
              this.goals[index] = updatedGoal;
            }
            this.resetForm();
            this.createGoalsChart();
            this.isLoading = false;
          },
          error: (error: any) => {
            console.error('Goal update failed', error);
            this.errorMessage = error.error?.message || 'Goal update failed';
            this.isLoading = false;
          }
        });
    } else {
      this.apiService.post('goals', formData)
        .subscribe({
          next: (response: any) => {
            const newGoal = response.goal;
            this.goals.unshift(newGoal);
            this.resetForm();
            this.createGoalsChart();
            this.isLoading = false;
          },
          error: (error: any) => {
            console.error('Goal creation failed', error);
            this.errorMessage = error.error?.message || 'Goal creation failed';
            this.isLoading = false;
          }
        });
    }
  }

  resetForm() {
    this.goalsForm.reset({
      goal: '',
      category: 'energy',
      initialData: 0,
      target: 0,
      date: ''
    });
    this.editingGoal = null;
  }

  private markFormGroupTouched(formGroup: FormGroup) {
    Object.values(formGroup.controls).forEach(control => {
      control.markAsTouched();
      if (control instanceof FormGroup) {
        this.markFormGroupTouched(control);
      }
    });
  }

  deleteGoal(goalId: string) {
    if (!confirm('Are you sure you want to delete this goal?')) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    this.apiService.delete(`goals/${goalId}`).subscribe({
      next: () => {
        this.goals = this.goals.filter(goal => goal.id !== goalId);
        this.createGoalsChart();
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Failed to delete goal', error);
        this.errorMessage = error.error?.message || 'Failed to delete goal';
        this.isLoading = false;
      }
    });
  }

  createGoalsChart() {
    if (this.chart) {
      this.chart.destroy();
    }

    if (!this.goalsChart?.nativeElement || this.goals.length === 0) {
      return;
    }

    try {
      const ctx = this.goalsChart.nativeElement.getContext('2d');
      const labels = this.goals.map(goal => goal.goal);
      const progressData = this.goals.map(goal => goal.progress || 0);
      const backgroundColors = progressData.map(progress => this.getBarColor(progress));

      this.chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Goal Progress (%)',
              data: progressData,
              backgroundColor: backgroundColors,
              borderWidth: 1,
              borderRadius: 5,
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            y: {
              beginAtZero: true,
              max: 100,
              title: {
                display: true,
                text: 'Progress (%)'
              }
            }
          },
          plugins: {
            title: {
              display: true,
              text: 'Sustainability Goals Progress'
            }
          }
        }
      });
    } catch (error) {
      console.error('Error creating chart:', error);
    }
  }

  getBarColor(progress: number): string {
    if (progress >= 90) return 'rgba(40, 167, 69, 0.8)';
    if (progress >= 50) return 'rgba(255, 193, 7, 0.8)';
    return 'rgba(220, 53, 69, 0.8)';
  }

  getProgressColor(progress: number): string {
    if (progress < 25) return 'danger';
    if (progress < 50) return 'warning';
    if (progress < 75) return 'info';
    return 'success';
  }

  trackGoalById(_index: number, goal: Goal): string {
    return goal.id;
  }

  getCategoryIcon(category: string): string {
    const categoryObj = this.categories.find(cat => cat.value === category);
    return categoryObj ? categoryObj.icon : '🌍';
  }
}