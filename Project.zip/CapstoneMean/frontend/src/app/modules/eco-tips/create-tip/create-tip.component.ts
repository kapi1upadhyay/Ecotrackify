import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { ApiService } from '../../../core/services/api.service';

@Component({
  selector: 'app-create-tip',
  standalone: true,  
  imports: [CommonModule, ReactiveFormsModule], 
  templateUrl: './create-tip.component.html',
  styleUrls: ['./create-tip.component.css']
})
export class CreateTipComponent {
  tipForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private apiService: ApiService,
    private router: Router
  ) {
    this.tipForm = this.fb.group({
      content: ['', [
        Validators.required, 
        Validators.minLength(5), 
        Validators.maxLength(500)
      ]],
      category: ['general', Validators.required]
    });
  }

  onSubmit() {
    if (this.tipForm.valid) {
      this.apiService.post('eco', this.tipForm.value)
        .subscribe({
          next: () => {
            this.router.navigate(['/eco-tips/list']);
          },
          error: (error) => {
            console.error('Tip creation failed:', error);
          }
        });
    }
  }

  // ✅ Navigate Back to Profile
  navigateToProfile() {
    this.router.navigate(['/dashboard/profile']);
  }
}
