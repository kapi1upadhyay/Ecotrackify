import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { CreateTipComponent } from './create-tip/create-tip.component';
import { TipListComponent } from './tip-list/tip-list.component';

@NgModule({
  declarations: [
    CreateTipComponent,
    TipListComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ]
})
export class EcoTipsModule { }