import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../../core/services/api.service';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

interface Tip {
  id: string;
  content: string;
  category: string;
}

@Component({
  selector: 'app-tip-list',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './tip-list.component.html',
  styleUrls: ['./tip-list.component.css'],
})
export class TipListComponent implements OnInit {
  tips: Tip[] = [];
  filteredTips: Tip[] = [];
  isLoading = true;

  constructor(private apiService: ApiService, private router: Router) {}

  ngOnInit() {
    this.fetchTips();
  }

  fetchTips() {
    this.apiService.get('eco').subscribe({
      next: (response: any) => {
        this.isLoading = false;
        console.log(response, 'response'); // ✅ Debug API response

        if (response?.tips?.length > 0) {
          this.tips = response.tips as Tip[];
          this.filteredTips = [...this.tips]; // ✅ Ensure filteredTips is set initially
        } else {
          this.tips = [];
          this.filteredTips = [];
        }
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Failed to fetch tips', error);
      },
    });
  }

  navigateToCreateTip() {
    this.router.navigate(['/eco-tips/create']);
  }

  filterTips(event: Event) {
    const category = (event.target as HTMLSelectElement).value.trim().toLowerCase();
    console.log(`Filtering by category: ${category}`); // ✅ Debug selected category

    this.filteredTips = category
      ? this.tips.filter((tip) => tip.category.trim().toLowerCase() === category)
      : [...this.tips];

    console.log(this.filteredTips, "filteredTips after filtering"); // ✅ Debug filtered tips
  }
}
