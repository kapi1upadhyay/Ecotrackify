import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule} from '@angular/forms';
import { Router } from '@angular/router';
import { GroupService } from '../../../core/services/services/group.service';
import { Group } from '../../../models/group.model';

@Component({
  selector: 'app-create-group',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl:'./create-group.component.html',
  styleUrls:['./create-group.component.css']
})
export class CreateGroupComponent {
  groupData: Group = {
    name: '',
    description: '',
    category: '' as any,
    privacy: 'public'
  };
  interestsInput = '';
  isSubmitting = false;
  errorMessage: string | null = null;

  constructor(
    private groupService: GroupService,
    private router: Router
  ) {}

  onSubmit() {
    this.isSubmitting = true;
    this.errorMessage = null;

    // Process interests
    const interests = this.interestsInput
      ? this.interestsInput.split(',').map(i => i.trim()).filter(i => i)
      : [];

    const submitData: Group = {
      ...this.groupData,
      interests
    };

    this.groupService.createGroup(submitData).subscribe({
      next: () => {
        this.isSubmitting = false;
        this.router.navigate(['/groups/list']);
      },
      error: (error) => {
        this.isSubmitting = false;
        this.errorMessage = error.error?.message || 'Failed to create group';
        console.error('Group creation error:', error);
      }
    });
  }
}