import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { GroupService } from '../../../core/services/services/group.service';
import { Group } from '../../../models/group.model';

@Component({
  selector: 'app-explore-groups',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl:'./explore-groups.component.html'
})
export class ExploreGroupsComponent implements OnInit {
  groups: Group[] = [];
  searchTerm = '';
  selectedCategory = '';
  isLoading = false;
  error: string | null = null;

  constructor(private groupService: GroupService) {}

  ngOnInit() {
    this.fetchExploreGroups();
  }

  fetchExploreGroups() {
    this.isLoading = true;
    this.error = null;

    this.groupService.exploreGroups().subscribe({
      next: (response) => {
        this.groups = response.groups;
        this.isLoading = false;
      },
      error: (error) => {
        this.error = 'Failed to load groups. Please try again.';
        this.isLoading = false;
        console.error('Explore groups error', error);
      }
    });
  }

  get filteredGroups() {
    return this.groups.filter(group => 
      group.name.toLowerCase().includes(this.searchTerm.toLowerCase()) &&
      (this.selectedCategory ? group.category === this.selectedCategory : true)
    );
  }

  joinGroup(groupId: string | undefined) {
    if (!groupId) return;

    this.groupService.joinGroup(groupId).subscribe({
      next: () => {
        alert('Successfully joined the group!');
        // Refresh explore groups to remove joined group
        this.fetchExploreGroups();
      },
      error: (error) => {
        console.error('Join group error', error);
        alert('Failed to join group. Please try again.');
      }
    });
  }
}