import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { GroupService } from '../../../core/services/services/group.service';
import { Group, Message } from '../../../models/group.model';

@Component({
  selector: 'app-group-detail',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './group-detail.component.html',
  styleUrls: ['./group-detail.component.css']
})
export class GroupDetailComponent implements OnInit {
  groupId: string | null = null;
  group: Group | null = null;
  messages: Message[] = [];
  newMessage = '';
  isLoading = false;
  error: string | null = null;
  userId: string = "";

  constructor(
    private route: ActivatedRoute,
    private groupService: GroupService
  ) {}

  ngOnInit() {
    this.groupId = this.route.snapshot.paramMap.get('id');
    if (this.groupId) {
      this.fetchGroupDetails();
      this.fetchGroupMessages();
      this.userId = localStorage.getItem('userId') ?? "";
    }
  }

  fetchGroupDetails() {
    this.isLoading = true;
    if (this.groupId) {
      this.groupService.getGroupDetail(this.groupId).subscribe({
        next: (group) => {
          this.group = group;
          this.isLoading = false;
        },
        error: (error) => {
          this.error = 'Failed to fetch group details';
          this.isLoading = false;
          console.error('Failed to fetch group details', error);
        }
      });
    }
  }

  fetchGroupMessages() {
    this.isLoading = true;
    if (this.groupId) {
      this.groupService.getGroupMessages(this.groupId).subscribe({
        next: (response) => {
          this.messages = response.messages;
          this.isLoading = false;
        },
        error: (error) => {
          this.error = 'Failed to fetch messages';
          this.isLoading = false;
          console.error('Failed to fetch messages', error);
        }
      });
    }
  }

  sendMessage() {
    if (this.groupId && this.newMessage.trim()) {
      this.groupService.sendMessage(this.groupId, this.newMessage).subscribe({
        next: (message) => {
          this.messages.push(message);
          this.newMessage = '';
          this.fetchGroupMessages();
        },
        error: (error) => {
          console.error('Failed to send message', error);
          alert('Failed to send message. Please try again.');
        }
      });
    }
  }
}