import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { GroupService } from '../../../core/services/services/group.service';
import { Group } from '../../../models/group.model';
import { ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-group-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl:'./group-list.component.html',
  styleUrls:['./group-list.component.css'],
  encapsulation: ViewEncapsulation.None
  
})
export class GroupListComponent implements OnInit {
  groups: Group[] = [];
  isLoading = false;
  error: string | null = null;

  constructor(
    private groupService: GroupService,
    private router: Router
  ) {}

  ngOnInit() {
    this.fetchGroups();
  }

  fetchGroups() {
    this.isLoading = true;
    this.error = null;

    this.groupService.getAllGroups().subscribe({
      next: (response) => {
        this.groups = response.groups;
        this.isLoading = false;
      },
      error: (error) => {
        this.error = 'Failed to load groups. Please try again.';
        this.isLoading = false;
        console.error('Groups fetch error', error);
      }
    });
  }

  navigateToCreateGroup() {
    this.router.navigate(['/groups/create']);
  }
}