import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { TokenService } from '../../core/services/token.service';

@Component({
  selector: 'app-login-navbar',
  templateUrl: './login-navbar.component.html',
  styleUrls: ['./login-navbar.component.css'],
  standalone: true,
  imports: [CommonModule, RouterModule]
})
export class LoginNavbarComponent implements OnInit {
  userType:string="";
  showDropdowns: { [key in 'dashboard' | 'groups' | 'ecoTips' | 'reports' | 'sustainableOptions']: boolean } = {
    dashboard: false,
    groups: false,
    ecoTips: false,
    reports: false,
    sustainableOptions: false
  };
  ngOnInit(): void {
      this.userType=localStorage.getItem('userType')??"";
  }

  selectedGroupId = 1; 

  constructor(private router: Router ,private tokenService:TokenService ) {}

  toggleDropdown(menu: keyof typeof this.showDropdowns, event: Event): void {
    event.preventDefault(); 
    this.showDropdowns[menu] = !this.showDropdowns[menu];

   
    (Object.keys(this.showDropdowns) as (keyof typeof this.showDropdowns)[]).forEach(key => {
      if (key !== menu) {
        this.showDropdowns[key] = false;
      }
    });
  }

  logout(): void {
    this.tokenService.removeToken()
    localStorage.removeItem('token'); 
    localStorage.removeItem('userId'); 
    localStorage.removeItem('userType'); 
    this.router.navigate(['/']); 
    
  }
}
