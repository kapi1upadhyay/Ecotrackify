// carbon-footprint.component.ts
import { Component, OnInit, ViewChild, ElementRef, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../../../core/services/api.service';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-carbon-footprint-report',
  templateUrl: './carbon-footprint.component.html',
  styleUrls: ['./carbon-footprint.component.css'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule]
})
export class CarbonFootprintReportComponent implements OnInit, OnDestroy {
  @ViewChild('carbonChart') carbonChart!: ElementRef;

  filterForm: FormGroup;
  carbonEntries: any[] = [];
  filteredEntries: any[] = [];
  chart: Chart | null = null;
  isLoading = false;
  errorMessage = '';

  constructor(
    private fb: FormBuilder, 
    private apiService: ApiService
  ) {
    this.filterForm = this.fb.group({
      startDate: [''],
      endDate: ['']
    });
  }

  ngOnInit() {
    this.fetchCarbonEntries();
  }

  ngOnDestroy() {
    if (this.chart) {
      this.chart.destroy();
    }
  }

  fetchCarbonEntries() {
    this.isLoading = true;
    this.apiService.get('carbon').subscribe({
      next: (response) => {
        this.carbonEntries = response.carbonEntries;
        this.applyFilters()
        // this.filteredEntries =response.carbonEntries
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Failed to fetch carbon entries', error);
        this.errorMessage = 'Failed to load carbon footprint data';
        this.isLoading = false;
      }
    });
  }

  applyFilters() {
    const { startDate, endDate } = this.filterForm.value;
    this.filteredEntries = this.carbonEntries.filter(entry => {
      const entryDate = new Date(entry.date);
      const start = startDate ? new Date(startDate) : null;
      const end = endDate ? new Date(endDate) : null;

      if (start && end) {
        return entryDate >= start && entryDate <= end;
      } else if (start) {
        return entryDate >= start;
      } else if (end) {
        return entryDate <= end;
      }
      return true;
    });
    this.createChart();
  }

  createChart() {
    if (this.chart) {
      this.chart.destroy();
    }

    if (!this.filteredEntries.length) {
      return;
    }

    const ctx = this.carbonChart.nativeElement.getContext('2d');

    this.chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: this.filteredEntries.map(entry => new Date(entry.date).toLocaleDateString()),
        datasets: [{
          label: 'Total Carbon Footprint',
          data: this.filteredEntries.map(entry => entry.totalFootprint),
          fill: false,
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Carbon Footprint (kg CO₂)'
            }
          }
        }
      }
    });
  }

  trackById(index: number, entry: any): number {
    return entry.id;
  }
}