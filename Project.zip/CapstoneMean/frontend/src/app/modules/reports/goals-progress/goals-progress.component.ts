import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { ApiService } from '../../../core/services/api.service';
import { Chart, registerables } from 'chart.js';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

Chart.register(...registerables);

@Component({
  selector: 'app-goals-progress-report',
  templateUrl: './goals-progress.component.html',
  styleUrls: ['./goals-progress.component.css'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule]
})
export class GoalsProgressReportComponent implements OnInit, AfterViewInit {
  @ViewChild('goalsChart') goalsChart!: ElementRef;
  
  filterOptions = {
    categories: [
      { value: '', label: 'All Categories' },
      { value: 'energy', label: 'Energy' },
      { value: 'transportation', label: 'Transportation' },
      { value: 'waste', label: 'Waste' },
      { value: 'water', label: 'Water' },
      { value: 'general', label: 'General' }
    ],
    progressRanges: [
      { value: '', label: 'All Progress Levels' },
      { value: 'notStarted', label: 'Not Started (0-10%)' },
      { value: 'inProgress', label: 'In Progress (11-50%)' },  
      { value: 'almostComplete', label: 'Almost Complete (51-90%)' },
      { value: 'completed', label: 'Completed (91-100%)' }
    ],
    dateRanges: [
      { value: '', label: 'All Time' },
      { value: 'thisMonth', label: 'This Month' },
      { value: 'lastMonth', label: 'Last Month' },
      { value: 'thisQuarter', label: 'This Quarter' },
      { value: 'thisYear', label: 'This Year' }
    ]
  };

  selectedCategory: string = '';
  selectedProgressRange: string = '';
  selectedDateRange: string = '';

  goals: any[] = [];
  filteredGoals: any[] = [];
  chart: Chart | null = null;
  isLoading = false;
  errorMessage = '';

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.fetchGoalsData();
  }

  ngAfterViewInit() {
    if (this.goals.length > 0) {
      this.createChart();
    }
  }

  fetchGoalsData() {
    this.isLoading = true;
    this.errorMessage = '';

    const params: any = {};
    
    if (this.selectedCategory) {
      params.category = this.selectedCategory;
    }

    if (this.selectedDateRange) {
      const now = new Date();
      let startDate = new Date(0), endDate = new Date();

      switch (this.selectedDateRange) {
        case 'thisMonth':
          startDate = new Date(now.getFullYear(), now.getMonth(), 1);
          endDate = new Date(now.getFullYear(), now.getMonth() + 1, 0);
          break;
        case 'lastMonth':
          startDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
          endDate = new Date(now.getFullYear(), now.getMonth(), 0); 
          break;
        case 'thisQuarter':
          const quarter = Math.floor((now.getMonth() + 3) / 3);
          startDate = new Date(now.getFullYear(), (quarter - 1) * 3, 1);
          endDate = new Date(now.getFullYear(), quarter * 3, 0);
          break;
        case 'thisYear':
          startDate = new Date(now.getFullYear(), 0, 1);
          endDate = new Date(now.getFullYear(), 11, 31);  
          break;
      }

      params.startDate = startDate.toISOString();
      params.endDate = endDate.toISOString();
    }

    this.apiService.get('goals', params).subscribe({
      next: (response) => {
        this.goals = response.goals || response || [];
        this.applyFilters();
        this.createChart();
        this.isLoading = false;
      }
    });
  }

  applyFilters() {
    this.filteredGoals = this.goals.filter(goal => {
      const categoryMatch = !this.selectedCategory || 
        goal.category === this.selectedCategory;

      const progressMatch = this.filterProgressRange(goal);

      return categoryMatch && progressMatch;
    });

    this.createChart();
  }

  filterProgressRange(goal: any): boolean {
    const progress = goal.progress || 0;
    switch(this.selectedProgressRange) {
      case 'notStarted': return progress <= 10;
      case 'inProgress': return progress > 10 && progress <= 50;
      case 'almostComplete': return progress > 50 && progress <= 90;
      case 'completed': return progress > 90;
      default: return true;
    }
  }

  createChart() {
    if (this.chart) {
      this.chart.destroy();
    }

    if (!this.goalsChart || !this.goalsChart.nativeElement) {
      return;
    }

    const ctx = this.goalsChart.nativeElement.getContext('2d');
    if (!ctx) return;

    this.chart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: this.filteredGoals.map((goal) => goal.goal),
        datasets: [
          {
            label: 'Progress (%)',
            data: this.filteredGoals.map((goal) => goal.progress || 0),
            backgroundColor: this.filteredGoals.map((goal) => this.getBarColor(goal.progress || 0)),
            borderWidth: 1,
            borderRadius: 5,
          },
        ],
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            title: {
              display: true,
              text: 'Progress (%)'
            }
          }
        },
        plugins: {
          title: {
            display: true,
            text: `Goals Progress: ${this.filteredGoals.length} goals`  
          }
        }
      },
    });
  }

  getBarColor(progress: number): string {
    if (progress >= 90) return 'rgba(40, 167, 69, 0.8)';  // Green
    if (progress >= 50) return 'rgba(255, 193, 7, 0.8)';  // Yellow
    return 'rgba(220, 53, 69, 0.8)';  // Red 
  }

  onFilterChange() {
    this.applyFilters();
  }
}