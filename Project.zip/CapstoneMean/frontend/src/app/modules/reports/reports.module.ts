import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { CarbonFootprintReportComponent } from './carbon-footprint/carbon-footprint.component';
import { GoalsProgressReportComponent } from './goals-progress/goals-progress.component';

@NgModule({
  declarations: [
    CarbonFootprintReportComponent,
    GoalsProgressReportComponent
  ],
  imports: [
    CommonModule,
    FormsModule,  
    RouterModule
  ],
  exports: [
    CarbonFootprintReportComponent,
    GoalsProgressReportComponent
  ]
})
export class ReportsModule { }