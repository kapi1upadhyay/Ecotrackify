export const environment = {
  production: true,
  apiUrl: 'https://your-production-api.com/api/v1'
};